"""
This code a slight modification of perplexity by hugging face
https://huggingface.co/docs/transformers/perplexity

Both this code and the orignal code are published under the MIT license.

by Burhan Ul tayyab and Nicholas Chua
"""
import os
import pandas as pd
from model import GPT2PPLV2 as GPT2PPL

# read essay from a files in the directory
def read_essay_from_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        return file.read()

# initialize the model
model = GPT2PPL()

# print("Please enter your sentence: (Press Enter twice to start processing)")
# contents = []
# while True:
#     line = input()
#     if len(line) == 0:
#         break
#     contents.append(line)
# sentence = "\n".join(contents)

def evaluate(sentence: str):
  result = model(sentence, 100, "v1.1")
  res = result[0]["prob"].strip("%")
  res = (100 - float(res))/100
  print(res)
  return res

# Define the directories for different types of essays
student_essay_path = "human"
gpt_essay_path = "/content/DetectGPT/gpt_essays"
word_sub_essay_path = "/content/DetectGPT/word_sub_essays"
sentence_essay_path = "/content/DetectGPT/sentence_sub_essays"
gpt_rep_essay_path = "/content/DetectGPT/gpt_rep_essays"

# Get the list of filenames from the word substitution essays directory
word_subs_essay_filenames = sorted(os.listdir(word_sub_essay_path))

# Filter essay files from each directory to include only those present in the word-substituted essays
directories = [gpt_essay_path, sentence_essay_path, gpt_rep_essay_path]
essay_files = {dir_path: sorted([os.path.join(dir_path, f) for f in os.listdir(dir_path) if f in word_subs_essay_filenames]) for dir_path in directories}

# Calculate the maximum number of essays to process based on the smallest category of available files
max_essays = min(len(files) for files in essay_files.values())
max_essays = min(21, max_essays)  # Ensure not to exceed 22 essays

# Limit the number of essays processed to max_essays and prepare for processing
essay_files = {dir_path: files[:max_essays] for dir_path, files in essay_files.items()}
word_sub_essay_files = [os.path.join(word_sub_essay_path, f) for f in word_subs_essay_filenames][:max_essays]

# Data container for the results
similarity_quality_results = []

# Process each pair of essays
for i in range(max_essays):
    gpt_essay = read_essay_from_file(essay_files[gpt_essay_path][i])
    gpt_detection_metrics =  evaluate(gpt_essay)
    sentence_substituted_essay = read_essay_from_file(essay_files[sentence_essay_path][i])
    ss_detection_metrics = evaluate(sentence_substituted_essay)
    gpt_rep_essay = read_essay_from_file(essay_files[gpt_rep_essay_path][i])
    rep_detection_metrics = evaluate(gpt_rep_essay)
    word_substituted_essay = read_essay_from_file(word_sub_essay_files[i])
    ws_detection_metrics = evaluate(word_substituted_essay)

    similarity_quality_results.append([
        os.path.basename(essay_files[gpt_essay_path][i]),
        gpt_detection_metrics, 
        rep_detection_metrics, 
        ss_detection_metrics,
        ws_detection_metrics, 
    ])
    print(similarity_quality_results)

# Define DataFrame columns and convert results to a DataFrame, then save to CSV
columns = [
    'Essay', 'GPT ACC', 'Rephrased ACC', 'Sentence Sub ACC', 'Word Sub ACC',
]
zero_similarity_df = pd.DataFrame(similarity_quality_results, columns=columns)
zero_similarity_df.to_csv("detectgpt_manipulation_results.csv")
zero_similarity_df


